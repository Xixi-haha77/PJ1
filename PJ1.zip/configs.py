class TrainingConfig:
    epochs = 35
    batch_size = 256
    initial_lr = 0.0015
    lr_decay = 0.9995
    momentum = 0.85
    dropout_rates = [0.3, 0.3]
    early_stop_patience = 5

class ModelConfig:
    hidden_sizes = [512, 256]
    input_size = 784
    output_size = 10
    weight_init = 'he'
    use_batchnorm = True