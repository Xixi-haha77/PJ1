import numpy as np
from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder

def load_mnist(test_size=0.2, random_state=42):
    """MNIST数据加载与预处理"""
    mnist = fetch_openml('mnist_784', version=1, parser='auto')
    
    # 将 pandas.Series 转换为 NumPy 数组
    X = mnist.data.to_numpy().astype(np.float32) / 255.0  # 显式转换为 NumPy
    y = mnist.target.to_numpy().astype(np.int32).reshape(-1, 1)  # 增加 to_numpy()
    
    # 兼容不同版本的OneHotEncoder
    try:
        encoder = OneHotEncoder(sparse_output=False)
    except TypeError:
        encoder = OneHotEncoder(sparse=False)
    
    y = encoder.fit_transform(y)
    return train_test_split(X, y, test_size=test_size, random_state=random_state)