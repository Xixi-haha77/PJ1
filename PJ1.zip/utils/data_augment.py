import numpy as np
from scipy.ndimage import rotate, shift

def random_rotate(images, max_angle=15):
    """随机旋转增强"""
    angles = np.random.uniform(-max_angle, max_angle, size=images.shape[0])
    return np.array([rotate(img.reshape(28,28), angle, reshape=False, mode='nearest').flatten()
                    for img, angle in zip(images, angles)])

def random_shift(images, max_shift=2):
    """随机平移增强"""
    return np.array([shift(img.reshape(28,28), 
                          np.random.randint(-max_shift, max_shift+1, size=2),
                          mode='constant').flatten()
                    for img in images])