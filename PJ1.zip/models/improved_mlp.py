import numpy as np

class ImprovedMLP:
    """改进版MLP：包含动量更新、学习率衰减和梯度裁剪"""
    def __init__(self, input_size=784, hidden_size=128, output_size=10):
        # Xavier初始化
        self.W1 = np.random.randn(input_size, hidden_size) * np.sqrt(2./(input_size+hidden_size))
        self.b1 = np.zeros(hidden_size)
        self.W2 = np.random.randn(hidden_size, output_size) * np.sqrt(2./(hidden_size+output_size))
        self.b2 = np.zeros(output_size)
        
        # 动量参数
        self.vW1 = np.zeros_like(self.W1)
        self.vb1 = np.zeros_like(self.b1)
        self.vW2 = np.zeros_like(self.W2)
        self.vb2 = np.zeros_like(self.b2)
    
    def relu(self, x):
        return np.maximum(0, x)
    
    def softmax(self, x):
        exps = np.exp(x - np.max(x, axis=1, keepdims=True))
        return exps / exps.sum(axis=1, keepdims=True)
    
    def forward(self, X):
        self.z1 = np.dot(X, self.W1) + self.b1
        self.a1 = self.relu(self.z1)
        self.z2 = np.dot(self.a1, self.W2) + self.b2
        return self.softmax(self.z2)
    
    def compute_loss(self, y_pred, y_true):
        epsilon = 1e-8
        return -np.mean(y_true * np.log(y_pred + epsilon))
    
    def backward(self, X, y_true, lr=0.01, beta=0.9, clip_threshold=5.0):
        m = X.shape[0]
        y_pred = self.forward(X)
        
        # 输出层梯度
        delta3 = (y_pred - y_true) / m
        dW2 = np.dot(self.a1.T, delta3)
        db2 = np.sum(delta3, axis=0)
        
        # 隐藏层梯度
        delta2 = np.dot(delta3, self.W2.T) * (self.z1 > 0)
        dW1 = np.dot(X.T, delta2)
        db1 = np.sum(delta2, axis=0)
        
        # 梯度裁剪
        dW2 = np.clip(dW2, -clip_threshold, clip_threshold)
        dW1 = np.clip(dW1, -clip_threshold, clip_threshold)
        db2 = np.clip(db2, -clip_threshold, clip_threshold)
        db1 = np.clip(db1, -clip_threshold, clip_threshold)
        
        # 动量更新
        self.vW2 = beta * self.vW2 + (1-beta) * dW2
        self.vb2 = beta * self.vb2 + (1-beta) * db2
        self.vW1 = beta * self.vW1 + (1-beta) * dW1
        self.vb1 = beta * self.vb1 + (1-beta) * db1
        
        # 参数更新
        self.W2 -= lr * self.vW2
        self.b2 -= lr * self.vb2
        self.W1 -= lr * self.vW1
        self.b1 -= lr * self.vb1