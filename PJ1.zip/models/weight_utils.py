import numpy as np

def save_weights(model, path):
    np.savez(path,
             W1=model.W1, b1=model.b1,
             W2=model.W2, b2=model.b2)

def load_weights(model, path):
    weights = np.load(path)
    model.W1 = weights['W1']
    model.b1 = weights['b1']
    model.W2 = weights['W2']
    model.b2 = weights['b2']