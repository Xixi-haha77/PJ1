import numpy as np

class BasicMLP:
    """基础全连接神经网络"""
    def __init__(self, input_size=784, hidden_size=128, output_size=10):
        self.W1 = np.random.randn(input_size, hidden_size) * 0.01
        self.b1 = np.zeros(hidden_size)
        self.W2 = np.random.randn(hidden_size, output_size) * 0.01
        self.b2 = np.zeros(output_size)

    def relu(self, x):
        return np.maximum(0, x)

    def softmax(self, x):
        exps = np.exp(x - np.max(x, axis=1, keepdims=True))
        return exps / exps.sum(axis=1, keepdims=True)

    def forward(self, X):
        self.z1 = np.dot(X, self.W1) + self.b1
        self.a1 = self.relu(self.z1)
        self.z2 = np.dot(self.a1, self.W2) + self.b2
        return self.softmax(self.z2)

    def compute_loss(self, y_pred, y_true):
        epsilon = 1e-8
        return -np.mean(y_true * np.log(y_pred + epsilon))

    def backward(self, X, y_true, lr=0.01):
        m = X.shape[0]
        y_pred = self.forward(X)
        
        # 输出层梯度
        delta3 = (y_pred - y_true) / m
        dW2 = np.dot(self.a1.T, delta3)
        db2 = np.sum(delta3, axis=0)
        
        # 隐藏层梯度
        delta2 = np.dot(delta3, self.W2.T) * (self.z1 > 0)
        dW1 = np.dot(X.T, delta2)
        db1 = np.sum(delta2, axis=0)
        
        # 参数更新
        self.W2 -= lr * dW2
        self.b2 -= lr * db2
        self.W1 -= lr * dW1
        self.b1 -= lr * db1