import numpy as np

class AdamMLP:
    def __init__(self, input_size=784, hidden_size=256, output_size=10):
        # He initialization
        self.W1 = np.random.randn(input_size, hidden_size) * np.sqrt(2./input_size)
        self.b1 = np.zeros(hidden_size)
        self.W2 = np.random.randn(hidden_size, output_size) * np.sqrt(2./hidden_size)
        self.b2 = np.zeros(output_size)
        
        # Adam parameters
        self.mW1, self.vW1 = np.zeros_like(self.W1), np.zeros_like(self.W1)
        self.mb1, self.vb1 = np.zeros_like(self.b1), np.zeros_like(self.b1)
        self.mW2, self.vW2 = np.zeros_like(self.W2), np.zeros_like(self.W2)
        self.mb2, self.vb2 = np.zeros_like(self.b2), np.zeros_like(self.b2)
        self.t = 1  # timestep counter

    def forward(self, X):
        # ... (同文档内容，此处省略具体实现)
        
    def backward(self, X, y_true, lr=0.001, beta1=0.9, beta2=0.999, epsilon=1e-8):
        # ... (包含Adam优化器和梯度裁剪的实现)