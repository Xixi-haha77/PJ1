# train.py
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix
from models.improved_mlp import ImprovedMLP
from utils.data_augment import augment_data

class Trainer:
    def __init__(self, model_type='improved', epochs=50, batch_size=64):
        self.model_type = model_type
        self.epochs = epochs
        self.batch_size = batch_size
        self.history = {'train_loss': [], 'train_acc': [], 'val_loss': [], 'val_acc': []}
        
        # 初始化模型
        if model_type == 'basic':
            from models.basic_mlp import BasicMLP
            self.model = BasicMLP()
        elif model_type == 'improved':
            self.model = ImprovedMLP()
        elif model_type == 'adam':
            from models.advanced_mlp import AdamMLP
            self.model = AdamMLP()
        else:
            raise ValueError("Invalid model type")

    def load_data(self, use_augment=False):
        """加载并预处理MNIST数据集"""
        mnist = fetch_openml('mnist_784', version=1)
        X, y = mnist.data.values.astype(np.float32), mnist.target.astype(int)
        
        # 数据预处理
        X = X / 255.0
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        
        # 数据增强
        if use_augment:
            X_train = augment_data(X_train.reshape(-1, 28, 28)).reshape(-1, 784)
        
        # 独热编码
        encoder = OneHotEncoder(sparse_output=False)
        y_train_onehot = encoder.fit_transform(y_train.reshape(-1, 1))
        y_test_onehot = encoder.transform(y_test.reshape(-1, 1))
        
        return X_train, X_test, y_train, y_test, y_train_onehot, y_test_onehot

    def train(self, X_train, y_train, X_val, y_val, y_train_onehot, y_val_onehot):
        """训练循环"""
        for epoch in range(self.epochs):
            epoch_loss = 0.0
            train_preds = []
            
            # 随机打乱数据
            indices = np.random.permutation(len(X_train))
            for i in range(0, len(X_train), self.batch_size):
                batch_indices = indices[i:i+self.batch_size]
                X_batch = X_train[batch_indices]
                y_batch = y_train_onehot[batch_indices]
                
                # 前向传播
                preds = self.model.forward(X_batch)
                loss = self.model.compute_loss(preds, y_batch)
                epoch_loss += loss
                
                # 反向传播
                self.model.backward(X_batch, y_batch)
                
                # 记录预测结果
                train_preds.extend(np.argmax(preds, axis=1))
            
            # 验证集评估
            val_preds = self.model.forward(X_val)
            val_loss = self.model.compute_loss(val_preds, y_val_onehot)
            val_acc = accuracy_score(y_val, np.argmax(val_preds, axis=1))
            
            # 记录指标
            train_acc = accuracy_score(y_train, train_preds)
            self.history['train_loss'].append(epoch_loss/len(X_train))
            self.history['train_acc'].append(train_acc)
            self.history['val_loss'].append(val_loss)
            self.history['val_acc'].append(val_acc)
            
            # 打印进度
            print(f"Epoch {epoch+1}/{self.epochs} | "
                  f"Train Loss: {self.history['train_loss'][-1]:.4f} | "
                  f"Val Loss: {val_loss:.4f} | "
                  f"Train Acc: {train_acc:.4f} | "
                  f"Val Acc: {val_acc:.4f}")

    def visualize_results(self, X_test, y_test):
        """生成所有可视化图表"""
        # 训练曲线
        self.plot_training_curve()
        
        # 混淆矩阵
        test_preds = np.argmax(self.model.forward(X_test), axis=1)
        self.plot_confusion_matrix(y_test, test_preds)
        
        # 梯度分布（仅限改进版）
        if hasattr(self.model, 'visualize_grad_distribution'):
            self.model.visualize_grad_distribution()

    def plot_training_curve(self):
        """绘制训练曲线"""
        plt.figure(figsize=(12, 5))
        
        plt.subplot(1, 2, 1)
        plt.plot(self.history['train_loss'], label='Training Loss')
        plt.plot(self.history['val_loss'], label='Validation Loss')
        plt.title('Loss Curve')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend()
        plt.grid(True)
        
        plt.subplot(1, 2, 2)
        plt.plot(self.history['train_acc'], label='Training Accuracy')
        plt.plot(self.history['val_acc'], label='Validation Accuracy')
        plt.title('Accuracy Curve')
        plt.xlabel('Epoch')
        plt.ylabel('Accuracy')
        plt.legend()
        plt.grid(True)
        
        plt.savefig(f'{self.model_type}_training_curve.png')
        plt.close()

    def plot_confusion_matrix(self, y_true, y_pred):
        """绘制混淆矩阵"""
        cm = confusion_matrix(y_true, y_pred)
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        
        plt.figure(figsize=(12, 10))
        sns.heatmap(cm, annot=True, fmt=".2f", cmap='Blues',
                    xticklabels=range(10), yticklabels=range(10))
        plt.title('Normalized Confusion Matrix')
        plt.xlabel('Predicted Label')
        plt.ylabel('True Label')
        plt.savefig(f'{self.model_type}_confusion_matrix.png')
        plt.close()

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Train MLP models on MNIST')
    parser.add_argument('--model', type=str, default='improved', 
                        choices=['basic', 'improved', 'adam'],
                        help='Model type to train')
    parser.add_argument('--epochs', type=int, default=50,
                        help='Number of training epochs')
    parser.add_argument('--batch_size', type=int, default=64,
                        help='Training batch size')
    parser.add_argument('--augment', action='store_true',
                        help='Use data augmentation')
    
    args = parser.parse_args()
    
    # 初始化训练器
    trainer = Trainer(
        model_type=args.model,
        epochs=args.epochs,
        batch_size=args.batch_size
    )
    
    # 加载数据
    X_train, X_test, y_train, y_test, y_train_onehot, y_test_onehot = trainer.load_data(
        use_augment=args.augment
    )
    
    # 拆分验证集
    X_train, X_val, y_train_onehot, y_val_onehot = train_test_split(
        X_train, y_train_onehot, test_size=0.1, random_state=42
    )
    
    # 训练模型
    trainer.train(X_train, y_train, X_val, y_test[:len(X_val)], y_train_onehot, y_val_onehot)
    
    # 最终评估和可视化
    test_preds = np.argmax(trainer.model.forward(X_test), axis=1)
    test_acc = accuracy_score(y_test, test_preds)
    print(f"\nFinal Test Accuracy: {test_acc:.4f}")
    
    # 生成可视化图表
    trainer.visualize_results(X_test, y_test)
    
    # 保存模型权重
    if hasattr(trainer.model, 'save_weights'):
        trainer.model.save_weights(f'{args.model}_weights.npz')